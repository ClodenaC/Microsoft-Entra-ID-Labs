# Approved Screenshots Only

Place manually reviewed, redacted screenshots here. No raw sensitive lab screenshots or passwords.
