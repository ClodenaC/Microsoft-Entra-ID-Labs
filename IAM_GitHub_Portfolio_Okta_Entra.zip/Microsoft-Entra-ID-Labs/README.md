# Microsoft Entra ID | IAM Lab Portfolio

## Overview
Hands-on Microsoft Entra ID labs emphasizing identity lifecycle operations, directory security groups, and API-driven administration via Postman and Microsoft Graph.

## Project 1: Microsoft Graph API User Provisioning (Completed milestone)
**Objective:** Create a fictitious directory user through the Microsoft Graph REST API.

**Tools:** Microsoft Entra ID, Microsoft Graph `/v1.0/users`, Postman.

**Work performed:**
1. Prepared a POST request to the Graph users endpoint using an authorized lab session.
2. Corrected the `userPrincipalName` to use the actual lab tenant domain.
3. Submitted the request and validated **HTTP 201 Created** for fictitious user **Jordan Smith**.

**Result:** Successful lab-user creation through a REST API request. This is a completed *provisioning milestone*, not proof of completion of the entire Graph + Okta automation lab.

## Project 2: Security Group Creation and Membership (Completed milestones)
**Objective:** Create a security group and assign a lab user using Microsoft Graph.

**Tools:** Microsoft Graph `/v1.0/groups`, `/groups/{id}/members/$ref`, Postman.

**Work performed:**
1. Created a fictitious security group named **Marketing Team** using `POST /v1.0/groups` → **HTTP 201 Created**.
2. Added **Jordan Smith** to the group using `POST /v1.0/groups/{id}/members/$ref` → **HTTP 204 No Content**.
3. Verified membership using GET on the group's members endpoint → **HTTP 200 OK**, with Jordan Smith in the response.

**Result:** Group creation, membership addition, and independent verification were demonstrated in the lab.

## Additional lab topics (Evidence review / training in progress)
- Microsoft Entra Conditional Access
- Access packages and approval workflows

These are documented as training topics rather than fully completed deployments pending final screenshot review and validation.

## Evidence
Screenshots are **not included** in this public-ready package until individually redacted and checked. The original lab evidence is retained privately. Add approved screenshots to `screenshots/` and link them here.

## Security note
Never commit real tokens, credentials, email addresses, tenant domains, or passwords. Sanitized example request structures may be added later, but raw Postman exports must be reviewed for secrets first.
