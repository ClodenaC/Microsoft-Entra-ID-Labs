# Approved Screenshots Only

Place manually reviewed, redacted screenshots here. Exclude authenticator QR codes, personal email addresses, tokens, and secrets.
