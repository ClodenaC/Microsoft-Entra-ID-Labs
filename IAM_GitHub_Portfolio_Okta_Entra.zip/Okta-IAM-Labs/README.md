# Okta Workforce Identity | IAM Lab Portfolio

## Overview
Hands-on training exercises in Okta Workforce Identity covering identity organization, administrative delegation, and authentication/federation concepts.

## Verified Okta Workforce Identity skill badges
The following **three earned badges** were confirmed as of October 21, 2026:
1. **Define Your Users in Okta**
2. **Organize Users with Groups**
3. **Define Okta Administrators**

A fourth badge was being pursued but is **not represented as earned**.

## Documented training areas
### User and group administration
- Okta directory user fundamentals
- Organizing identities with Okta groups
- Administrator role fundamentals and delegated access concepts

### Authentication and policy exercises
- Okta network zones
- Authenticator enrollment and verification configuration
- Enrollment policy rules

### Federation and access topics (lab evidence pending review)
- SAML SSO concepts and lab exercises
- OpenID Connect (OIDC) lab exercises
- Okta Access Requests

These topics represent training exposure and collected lab evidence. **They are not all claimed as independently completed implementations.** In particular, device-registration work is not marked completed.

## Portfolio evidence
Original lab screenshots are held privately. Reviewed, redacted exports can be added to `screenshots/` along with the related task objective and outcome. Do not upload authenticator enrollment QR codes, private email addresses, tenant/app secrets, or live security details.

## Skills developed
Okta user organization, group-based identity management, administration concepts, authentication-policy awareness, SSO protocol familiarity, and concise evidence-based lab documentation.
