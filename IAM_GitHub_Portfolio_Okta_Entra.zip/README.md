# IAM Cloud Engineering | GitHub Portfolio

Hands-on identity and access management (IAM) projects using **Microsoft Entra ID**, **Microsoft Graph API**, and **Okta Workforce Identity**.

## Featured repositories

| Repository | Focus |
|---|---|
| [Microsoft Entra ID Labs](Microsoft-Entra-ID-Labs/) | Microsoft Graph provisioning, security groups, access and identity controls |
| [Okta IAM Labs](Okta-IAM-Labs/) | Users, groups, delegated administration, authentication and federation lab topics |

> **Portfolio status:** Documentation is limited to confirmed outcomes. Other training exercises are labeled as explored/in progress, not represented as completed production implementations.

## Skills demonstrated
- Identity lifecycle fundamentals, user account provisioning, and directory group membership
- Microsoft Graph REST operations using Postman
- API response validation and verification
- Okta user, group, and administrative access concepts
- Exposure to SAML SSO, OpenID Connect (OIDC), authenticator policies, and access request exercises
- Safe IAM documentation practices

## Evidence and confidentiality
Lab work uses fictitious identities. Public copies must not contain access tokens, passwords, client secrets, tenant identifiers, personal emails, MFA enrollment QR codes, or confidential configurations. Original screenshots are retained in private archives, **not included here**. Only carefully reviewed redacted screenshots should be added to `screenshots/`.

## About
An IAM Cloud Engineering learner building practical skills in identity administration, access control, and API-based automation. This repository illustrates hands-on training, not administration of an enterprise production environment.
