# Before publishing to GitHub

- [ ] Replace any personal or tenant email/domain names with neutral placeholders.
- [ ] Remove temporary passwords, API tokens, OAuth secrets, keys, QR codes, and cookie/header values.
- [ ] Check backgrounds, browser tabs, URL bars, and Postman environment variables.
- [ ] Strip metadata if necessary and review each redacted image at full resolution.
- [ ] Never commit original unredacted archives or raw Postman collections with credentials.
- [ ] Label in-progress labs accurately and do not claim production administration.
- [ ] Upload each project folder as its own GitHub repository; optionally use root README as profile landing-page copy.
